package com.webstore.dao.implementations;

import com.webstore.dao.interfacecs.AccountDao;
import com.webstore.helper.PostgressConnHelper;
import com.webstore.models.Address;
import com.webstore.models.CreditCard;
import com.webstore.models.UserAccount;

import java.sql.*;
import java.util.ResourceBundle;

public class AccountDAO implements AccountDao {

    private Connection conn;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;
    private PreparedStatement pre;

    public AccountDAO(){
        conn = PostgressConnHelper.getConnection();
        resourceBundle=ResourceBundle.getBundle("db");
    }

    public void addUserAccount(UserAccount userAccount) throws SQLException {
        String addAddress=resourceBundle.getString("addAddress");
        String addUser=resourceBundle.getString("addUser");
        try {
            pre = conn.prepareStatement(addAddress);
            pre.setInt(1,userAccount.getAddress().getId());
            pre.setString(2,userAccount.getAddress().getType());
            pre.setString(3,userAccount.getAddress().getAddress());
            pre.setString(4,userAccount.getAddress().getCity());
            pre.setString(5,userAccount.getAddress().getState());
            pre.setString(6,userAccount.getAddress().getCountry());
            pre.setInt(7,userAccount.getAddress().getZip());

            pre.executeUpdate();

            pre = conn.prepareStatement(addUser);
            pre.setInt(1,userAccount.getId());
            pre.setString(2,userAccount.getFName());
            pre.setString(3,userAccount.getLName());
            pre.setString(4,userAccount.getPassword());
            pre.setLong(5,userAccount.getAddress().getPhoneNo());
            pre.setString(6,userAccount.getEmailId());
            pre.setInt(7, userAccount.getAddress().getId());
            pre.executeUpdate();
            conn.commit();
        }
        catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            conn.rollback();
        }
    }

    @Override
    public UserAccount getUserAccount(int id) throws SQLException {
        String selectUserAccountId=resourceBundle.getString("selectUserAccountId");
        UserAccount userAccount = null;
        Address address = null;
        pre = conn.prepareStatement(selectUserAccountId);
        pre.setInt(1,id);
        resultSet=pre.executeQuery();
        if(resultSet.next())
        {
            userAccount=new UserAccount();
            userAccount.setId(resultSet.getInt("user_id"));
            userAccount.setFName(resultSet.getString("f_name"));
            userAccount.setLName(resultSet.getString("l_name"));
            userAccount.setEmailId(resultSet.getString("email_id"));
            userAccount.setAddress(getAddress(resultSet.getInt("address_id")));
            userAccount.setPassword(resultSet.getString("password"));
        }
        return userAccount;
    }


    @Override
    public Address getAddress(int id) throws SQLException {
        String selectAddress=resourceBundle.getString("selectAddress");
        Address address = null;
        PreparedStatement Apre = conn.prepareStatement(selectAddress);
        Apre.setInt(1,id);
        ResultSet resultSet=Apre.executeQuery();
        if(resultSet.next())
        {
            address=new Address();
            address.setId(resultSet.getInt("address_id"));
            address.setType(resultSet.getString("type"));
            address.setAddress(resultSet.getString("address"));
            address.setCity(resultSet.getString("city"));
            address.setState(resultSet.getString("state"));
            address.setCountry(resultSet.getString("country"));
            address.setZip(resultSet.getInt("zip"));
        }
        return address;
    }

    @Override
    public UserAccount getUserAccount(String username, String password) throws SQLException {
        String selectUserAccountPassword=resourceBundle.getString("selectUserAccountPassword");
        UserAccount userAccount = null;
        Address address = null;
        pre = conn.prepareStatement(selectUserAccountPassword);
        pre.setString(1,username);
        pre.setString(2,password);
        resultSet=pre.executeQuery();
        if(resultSet.next())
        {
            userAccount=new UserAccount();
            userAccount.setId(resultSet.getInt("user_id"));
            userAccount.setFName(resultSet.getString("f_name"));
            userAccount.setLName(resultSet.getString("l_name"));
            userAccount.setEmailId(resultSet.getString("email_id"));
            userAccount.setAddress(getAddress(resultSet.getInt("address_id")));
            userAccount.setPassword(resultSet.getString("password"));
        }
        return userAccount;
    }

    @Override
    public UserAccount getUserAccount(String username) throws SQLException {
        String selectUserAccountName=resourceBundle.getString("selectUserAccountName");
        UserAccount userAccount = null;
        Address address = null;
        pre = conn.prepareStatement(selectUserAccountName);
        pre.setString(1,username);
        resultSet=pre.executeQuery();
        if(resultSet.next())
        {
            userAccount=new UserAccount();
            userAccount.setId(resultSet.getInt("user_id"));
            userAccount.setFName(resultSet.getString("f_name"));
            userAccount.setLName(resultSet.getString("l_name"));
            userAccount.setEmailId(resultSet.getString("email_id"));
            userAccount.setAddress(getAddress(resultSet.getInt("address_id")));
            userAccount.setPassword(resultSet.getString("password"));
        }
        return userAccount;
    }

    @Override
    public CreditCard getCreditCard(int id) throws SQLException {
        String selectCreditCard=resourceBundle.getString("selectCreditCard");
        CreditCard creditCard = null;
        pre = conn.prepareStatement(selectCreditCard);
        pre.setInt(1,id);
        resultSet=pre.executeQuery();
        if(resultSet.next())
        {
            creditCard=new CreditCard();
            creditCard.setId(resultSet.getInt("card_id"));
            creditCard.setType(resultSet.getString("type"));
            creditCard.setNumber(resultSet.getInt("number"));
            creditCard.setExpDate(resultSet.getDate("expiry_date"));
        }
        return creditCard;
    }
}

package com.webstore.dao.implementations;

import com.webstore.dao.interfacecs.CatalogDao;
import com.webstore.helper.PostgressConnHelper;
import com.webstore.models.Catalog;
import com.webstore.models.Category;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CatalogDAO implements CatalogDao {

    private Connection conn;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;
    private PreparedStatement pre;

    public CatalogDAO(){
        conn = PostgressConnHelper.getConnection();
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public void addCatalog(Catalog catalog) throws SQLException {
        String addCatalog=resourceBundle.getString("addCatalog");
        try {
            pre = conn.prepareStatement(addCatalog);
            pre.setInt(1,catalog.getId());
            pre.setString(2,catalog.getName());
            pre.setString(3,catalog.getDescription());
            pre.executeUpdate();
            conn.commit();

        }
        catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            conn.rollback();
        }
    }

    @Override
    public void addCategory(Category category) throws SQLException {
        String addCategory=resourceBundle.getString("addCategory");
        try {
            pre = conn.prepareStatement(addCategory);
            pre.setInt(1,category.getId());
            pre.setInt(2,category.getSuperiorCategory());
            pre.setString(3,category.getName());
            pre.setString(4,category.getDescription());
            pre.executeUpdate();
            conn.commit();

        }
        catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            conn.rollback();
        }
    }

    @Override
    public Catalog getCatalog(int id) throws SQLException {
        String selectCatalog=resourceBundle.getString("selectCatalog");
        Catalog catalog = null;
        pre = conn.prepareStatement(selectCatalog);
        pre.setInt(1,id);
        resultSet=pre.executeQuery();
        if(resultSet.next())
        {
            catalog = new Catalog();
            catalog.setId(resultSet.getInt("catalog_id"));
            catalog.setDescription(resultSet.getString("description"));
            catalog.setName(resultSet.getString("name"));
        }
        return catalog;
    }

    @Override
    public List<Catalog> getCatalogs() throws SQLException {
        List<Catalog> catalogs = new ArrayList<>();
        String selectCatalogs=resourceBundle.getString("selectCatalogs");
        Catalog catalog = null;
        pre = conn.prepareStatement(selectCatalogs);
        resultSet=pre.executeQuery();
        while(resultSet.next())
        {
            catalog = new Catalog();
            catalog.setId(resultSet.getInt(1));
            catalog.setDescription(resultSet.getString(3));
            catalog.setName(resultSet.getString(2));
            catalogs.add(catalog);
        }
        return catalogs;
    }
}

package com.webstore.dao.implementations;

import com.webstore.dao.interfacecs.CategoryDao;
import com.webstore.helper.PostgressConnHelper;
import com.webstore.models.Catalog;
import com.webstore.models.Category;
import com.webstore.models.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CategoryDAO implements CategoryDao {

    private Connection conn;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;
    private PreparedStatement pre;

    public CategoryDAO(){
        conn = PostgressConnHelper.getConnection();
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public void addProduct(Product product) throws SQLException {
        String addProduct=resourceBundle.getString("addProduct");
        try {
            pre = conn.prepareStatement(addProduct);
            pre.setInt(1,product.getId());
            pre.setString(2,product.getName());
            pre.setString(3,product.getDescription());
            pre.setInt(4,product.getCost());
            pre.executeUpdate();
            conn.commit();
        }
        catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            conn.rollback();
        }
    }


    @Override
    public List<Category> getCategory() throws SQLException {
        Category category = null;
        List<Category> categories = new ArrayList<>();
        String selectCategories=resourceBundle.getString("selectCategories");
        pre = conn.prepareStatement(selectCategories);
        resultSet=pre.executeQuery();
        while(resultSet.next())
        {
            category = new Category();
            category.setId(resultSet.getInt("category_id"));
            category.setDescription(resultSet.getString("description"));
            category.setSuperiorCategory(resultSet.getInt("super_category_id"));
            category.setName(resultSet.getString("name"));
            categories.add(category);
        }
        return categories;
    }


    @Override
    public List<Product> getProducts() throws SQLException {
        List<Product> products = null;
        Product product = null;
        String selectProducts=resourceBundle.getString("selectProducts");
        pre = conn.prepareStatement(selectProducts);
        resultSet=pre.executeQuery();
        while(resultSet.next())
        {
            product = new Product();
            product.setId(resultSet.getInt("product_id"));
            product.setDescription(resultSet.getString("description"));
            product.setName(resultSet.getString("name"));
            product.setCost(resultSet.getInt("price"));
            products.add(product);
        }
        return products;
    }

}

package com.webstore.dao.implementations;

import com.webstore.dao.interfacecs.ItemDao;
import com.webstore.models.Address;
import com.webstore.models.Item;
import com.webstore.models.UserAccount;

import java.sql.*;
import java.util.ResourceBundle;

public class ItemDAO implements ItemDao {
    private Connection conn;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;
    private PreparedStatement pre;

    @Override
    public Item getItem(int id) throws SQLException {

        return null;
    }
}

package com.webstore.dao.implementations;

import com.webstore.dao.interfacecs.OrderDao;
import com.webstore.helper.PostgressConnHelper;
import com.webstore.models.*;

import java.sql.*;
import java.time.LocalDate;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;
import java.util.ResourceBundle;

public class OrderDAO implements OrderDao {

    private Connection conn;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;
    private PreparedStatement pre,cartPre;

    public OrderDAO(){
        conn = PostgressConnHelper.getConnection();
        resourceBundle=ResourceBundle.getBundle("db");
    }
    @Override
    public void addOrder(Order order) throws SQLException {
        String addOrder=resourceBundle.getString("addOrder");
        String addOrderProduct=resourceBundle.getString("addOrderProduct");
        try {
            pre = conn.prepareStatement(addOrder);
            pre.setInt(1,order.getId());
            pre.setInt(2,order.getUserAccount().getId());
            pre.setDate(3, Date.valueOf(order.getDate()));
            pre.setInt(4,order.getCreditCard().getId());
            pre.setInt(5,order.getShippingAddress().getId());
            pre.executeUpdate();

            List<CartProduct> cartProduct = order.getCart().getCartProduct();
            ListIterator<CartProduct> listIterator = cartProduct.listIterator();
            while(listIterator.hasNext())
            {
                CartProduct cartProduct1 = listIterator.next();
                cartPre = conn.prepareStatement(addOrderProduct);
                cartPre.setInt(1,new Random().nextInt(100000));
                cartPre.setInt(2,order.getId());
                cartPre.setInt(3,cartProduct1.getProduct().getId());
                cartPre.setInt(4,cartProduct1.getQuantity());
                cartPre.executeUpdate();
            }
            conn.commit();
        }
        catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            conn.rollback();
        }
    }

    @Override
    public Order getOrder(int id) throws SQLException {
        Order order = null;
        String selectOrder=resourceBundle.getString("selectOrder");
        pre = conn.prepareStatement(selectOrder);
        pre.setInt(1,id);
        resultSet=pre.executeQuery();
        AccountDAO AccountDAO = new AccountDAO();
        if(resultSet.next())
        {
            order = new Order();
            order.setId(resultSet.getInt("order_id"));
            order.setUserAccount(AccountDAO.getUserAccount(resultSet.getInt("user_id")));
            order.setShippingAddress(AccountDAO.getUserAccount(resultSet.getInt("user_id")).getAddress());
            order.setCreditCard(AccountDAO.getCreditCard(resultSet.getInt("card_id")));

        }
        return order;
    }

    @Override
    public List<Order> getOrders(UserAccount userAccount) throws SQLException {
        List<Order> orders = null;
        Order order = null;
        String selectOrders=resourceBundle.getString("selectOrders");
        pre = conn.prepareStatement(selectOrders);
        pre.setInt(1,userAccount.getId());
        resultSet=pre.executeQuery();
        AccountDAO AccountDAO = new AccountDAO();
        while(resultSet.next())
        {
            order = new Order();
            order.setId(resultSet.getInt("order_id"));
            order.setUserAccount(AccountDAO.getUserAccount(resultSet.getInt("user_id")));
            order.setShippingAddress(AccountDAO.getUserAccount(resultSet.getInt("user_id")).getAddress());
            order.setCreditCard(AccountDAO.getCreditCard(resultSet.getInt("card_id")));
            orders.add(order);
        }
        return orders;
    }
}

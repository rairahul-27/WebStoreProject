package com.webstore.dao.implementations;

import com.webstore.dao.interfacecs.ProductDao;
import com.webstore.helper.PostgressConnHelper;
import com.webstore.models.Category;
import com.webstore.models.Item;
import com.webstore.models.Order;
import com.webstore.models.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class ProductDAO implements ProductDao {
    private Connection conn;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;
    private PreparedStatement pre;

    public ProductDAO(){
        conn = PostgressConnHelper.getConnection();
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public void addItem(Item item) throws SQLException {
        String addItem=resourceBundle.getString("addItem");
        try {
            pre = conn.prepareStatement(addItem);
            pre.setInt(1,item.getId());
            pre.setInt(2,item.getPrice());
            pre.setBoolean(3,item.isAvailable());
            pre.executeUpdate();
            conn.commit();
        }
        catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            conn.rollback();
        }
    }

    @Override
    public Product getProduct(int id) throws SQLException {
        Product product = null;
        String selectProduct=resourceBundle.getString("selectProduct");
        pre = conn.prepareStatement(selectProduct);
        pre.setInt(1,id);
        resultSet=pre.executeQuery();
        AccountDAO AccountDAO = new AccountDAO();
        if(resultSet.next())
        {
            product = new Product();
            product.setId(resultSet.getInt("product_id"));
            product.setDescription(resultSet.getString("description"));
            product.setName(resultSet.getString("name"));
            product.setCost(resultSet.getInt("price"));
        }
        return product;
    }

}

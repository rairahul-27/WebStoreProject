package com.webstore.dao.interfacecs;

import com.webstore.models.Address;
import com.webstore.models.CreditCard;
import com.webstore.models.UserAccount;

import java.sql.SQLException;

public interface AccountDao {
    public void addUserAccount(UserAccount userAccount) throws SQLException;
    public UserAccount getUserAccount(int id) throws SQLException;
    public Address getAddress(int id) throws SQLException;
    public UserAccount getUserAccount(String username,String password) throws SQLException;
    public UserAccount getUserAccount(String username) throws SQLException;
    public CreditCard getCreditCard(int id) throws SQLException;

}

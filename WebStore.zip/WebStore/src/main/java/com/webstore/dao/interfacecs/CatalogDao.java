package com.webstore.dao.interfacecs;

import com.webstore.models.Catalog;
import com.webstore.models.Category;

import java.sql.SQLException;
import java.util.List;

public interface CatalogDao {
    public void addCatalog(Catalog catalog) throws SQLException;
    public void addCategory(Category category) throws SQLException;
    public Catalog getCatalog(int id) throws SQLException;
    public List<Catalog> getCatalogs() throws SQLException;
}

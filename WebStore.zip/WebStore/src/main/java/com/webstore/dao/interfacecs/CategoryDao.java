package com.webstore.dao.interfacecs;

import com.webstore.models.Category;
import com.webstore.models.Product;

import java.sql.SQLException;
import java.util.List;

public interface CategoryDao {
    public void addProduct(Product product) throws SQLException;

    List<Category> getCategory() throws SQLException;

    public List<Product> getProducts() throws SQLException;
}

package com.webstore.dao.interfacecs;

import com.webstore.models.Item;
import com.webstore.models.Order;
import com.webstore.models.UserAccount;

import java.sql.SQLException;
import java.util.List;

public interface ItemDao {

    public Item getItem(int id) throws SQLException;
}

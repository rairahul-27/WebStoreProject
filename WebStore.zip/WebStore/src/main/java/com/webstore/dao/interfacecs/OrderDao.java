package com.webstore.dao.interfacecs;

import com.webstore.models.Order;
import com.webstore.models.UserAccount;

import java.sql.SQLException;
import java.util.List;

public interface OrderDao {
    public void addOrder(Order order) throws SQLException;
    public Order getOrder(int id) throws SQLException;
    public List<Order> getOrders(UserAccount userAccount) throws SQLException;
}

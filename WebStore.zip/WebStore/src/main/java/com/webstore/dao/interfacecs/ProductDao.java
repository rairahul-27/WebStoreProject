package com.webstore.dao.interfacecs;

import com.webstore.models.Item;
import com.webstore.models.Product;

import java.sql.SQLException;
import java.util.List;

public interface ProductDao {
    public void addItem(Item item) throws SQLException;
    public Product getProduct(int id) throws SQLException;
}

package com.webstore.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Catalog {
    private String name;
    private int id;
    private String description;
    private Set<Category> categories;
    private Image image;
}

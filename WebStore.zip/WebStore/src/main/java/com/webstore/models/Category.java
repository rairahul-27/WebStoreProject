package com.webstore.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Category extends Catalog{
    private String name;
    private String description;
    private int id;
    private int superiorCategory;
    private Set<Product> products;
    private Image image;
}

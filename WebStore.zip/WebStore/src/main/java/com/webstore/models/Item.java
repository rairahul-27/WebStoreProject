package com.webstore.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Item extends Product{
    private String name;
    private int id;
    private String description;
    private int price;
    private Image image;
    private boolean available;
}

package com.webstore.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Order {
    private int id;
    private UserAccount userAccount;
    private Cart cart;
    private String orderStatus;
    private CreditCard creditCard;
    private Address shippingAddress;
    private LocalDate date;

}

package com.webstore.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product extends Category{
    private String name;
    private int id;
    private String description;
    private int cost;
    private int units;
    private Set<Item> items;
    private Image image;
}

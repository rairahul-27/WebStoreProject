package com.webstore.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserAccount {
    private int id;
    private String FName;
    private String LName;
    private LocalDate birthDate;
    private String emailId;
    private Address address;
    private String userName;
    private String password;
}

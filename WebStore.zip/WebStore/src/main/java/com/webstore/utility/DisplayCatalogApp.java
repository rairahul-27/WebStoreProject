package com.webstore.utility;

import com.webstore.dao.implementations.CatalogDAO;

import java.sql.SQLException;

public class DisplayCatalogApp {
    public static void main(String[] args) {
        CatalogDAO catalogDAO = new CatalogDAO();
        try {
            catalogDAO.getCatalogs().stream().forEach(System.out::println);
        } catch (SQLException exception) {
            System.out.println(exception.getMessage());
        }
    }
}

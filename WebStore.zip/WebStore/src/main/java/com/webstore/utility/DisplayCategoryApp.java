package com.webstore.utility;

import com.webstore.dao.implementations.CatalogDAO;
import com.webstore.dao.implementations.CategoryDAO;

import java.sql.SQLException;

public class DisplayCategoryApp {
    public static void main(String[] args) {
        CategoryDAO categoryDAO = new CategoryDAO();
        try {
            categoryDAO.getCategory().stream().forEach(System.out::println);
        } catch (SQLException exception) {
            System.out.println(exception.getMessage());
        }
    }
}

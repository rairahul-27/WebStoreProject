package com.webstore.utility;

import com.webstore.dao.implementations.AccountDAO;
import com.webstore.dao.implementations.CategoryDAO;
import com.webstore.dao.implementations.OrderDAO;
import com.webstore.dao.implementations.ProductDAO;
import com.webstore.models.*;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;
import java.util.Scanner;

public class OrderApp {
    public static void main(String[] args) {

        // creating Cart
        Cart cart = new Cart();
        cart.setId(new Random().nextInt(1000));

        //adding products to cart
        for(int i=1;i<5;i++){
            ProductDAO productDAO = new ProductDAO();
            try {
                Product product = productDAO.getProduct(i);
                CartProduct cartProduct = new CartProduct(product,i*2);
                cart.addProduct(cartProduct);
            } catch (SQLException exception) {
                System.out.println(exception.getMessage());
            }
        }

        //creating user account
        Address address = getAddress();
        UserAccount userAccount = getUserAccount();
        userAccount.setAddress(address);
        AccountDAO accountDAO = new AccountDAO();
        try {
            accountDAO.addUserAccount(userAccount);
        } catch (Exception exception) {
            System.out.println(exception.getMessage());
        }

        CreditCard creditCard = null;
        try {
            creditCard = accountDAO.getCreditCard(1);
        } catch (Exception exception) {
            System.out.println(exception.getMessage());
        }

        //creating an order
        Order order = new Order();
        order.setId(new Random().nextInt(1000));
        order.setDate(LocalDate.now());
        order.setCart(cart);
        order.setCreditCard(creditCard);
        order.setUserAccount(userAccount);
        order.setShippingAddress(userAccount.getAddress());
        order.setOrderStatus("Active");

        OrderDAO orderDAO = new OrderDAO();
        try {
            orderDAO.addOrder(order);
        } catch (SQLException exception) {
            System.out.println(exception.getMessage());
        }

        // Displaying the Order
        System.out.println("Order Created Successfully...");
        List<CartProduct> cartProduct = order.getCart().getCartProduct();
        ListIterator<CartProduct> listIterator = cartProduct.listIterator();
        while(listIterator.hasNext())
        {
            CartProduct cartProduct1 = listIterator.next();
            System.out.print("Product : "+cartProduct1.getProduct().getName());
            System.out.print(" Cost : "+cartProduct1.getProduct().getCost());
            System.out.println(" Quantity : "+cartProduct1.getQuantity());
        }

    }

    public static UserAccount getUserAccount(){
        Scanner sc = new Scanner(System.in);
        UserAccount userAccount = new UserAccount();
        userAccount.setId(new Random().nextInt(10000));

        String fname,lname,email_id,password;
        System.out.print("Enter first name : ");
        fname = sc.next();

        System.out.print("Enter last name : ");
        lname = sc.next();

        System.out.print("Enter email ID : ");
        email_id = sc.next();

        System.out.print("Enter password : ");
        password = sc.next();

        userAccount.setPassword(password);
        userAccount.setEmailId(email_id);
        userAccount.setLName(lname);
        userAccount.setFName(fname);
        return userAccount;
    }

    public static Address getAddress(){
        Scanner sc = new Scanner(System.in);
        Address address = new Address();
        address.setId( new Random().nextInt(10000));
        String adrs, city,state,country,type;
        int zip;

        System.out.print("Enter address : ");
        adrs = sc.nextLine();

        System.out.print("Enter City : ");
        city = sc.next();

        System.out.print("Enter state : ");
        state = sc.next();

        System.out.print("Enter country : ");
        country = sc.next();

        System.out.print("Enter type : ");
        type = sc.next();

        System.out.print("Enter ZIP : ");
        zip = sc.nextInt();

        address.setAddress(adrs);
        address.setZip(zip);
        address.setCountry(country);
        address.setCity(city);
        address.setState(state);
        address.setType(type);

        return address;
    }
}


package com.webstore.utility;

import com.webstore.dao.implementations.AccountDAO;
import com.webstore.dao.implementations.CategoryDAO;
import com.webstore.models.Category;
import com.webstore.models.Product;

import java.sql.SQLException;
import java.util.Random;
import java.util.Scanner;

public class addProductApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Product product = new Product();
        product.setId(new Random().nextInt(10000));
        System.out.print("Enter Product Name : ");
        String name = sc.nextLine();
        System.out.print("Enter Product Description : ");
        String desc = sc.nextLine();
        System.out.print("Enter Product Price : ");
        int price = sc.nextInt();
        product.setName(name);
        product.setDescription(desc);
        product.setCost(price);

        CategoryDAO categoryDAO = new CategoryDAO();
        try {
            categoryDAO.addProduct(product);
        } catch (SQLException exception) {
            System.out.print(exception.getMessage());
        }
    }
}

package com.webstore.utility;

import com.webstore.dao.implementations.AccountDAO;
import com.webstore.dao.interfacecs.AccountDao;
import com.webstore.models.Address;
import com.webstore.models.UserAccount;

import java.sql.SQLException;
import java.util.Random;
import java.util.Scanner;

public class addUserApp {
    public static void main(String[] args)  {
        Address address = getAddress();
        UserAccount userAccount = getUserAccount();
        userAccount.setAddress(address);
        AccountDAO AccountDAO = new AccountDAO();
        try {
            AccountDAO.addUserAccount(userAccount);
        } catch (Exception exception) {
            System.out.println(exception.getMessage());
        }
    }

    public static UserAccount getUserAccount(){
        Scanner sc = new Scanner(System.in);
        UserAccount userAccount = new UserAccount();
        userAccount.setId(new Random().nextInt(10000));

        String fname,lname,email_id,password;
        System.out.print("Enter first name : ");
        fname = sc.next();

        System.out.print("Enter last name : ");
        lname = sc.next();

        System.out.print("Enter email ID : ");
        email_id = sc.next();

        System.out.print("Enter password : ");
        password = sc.next();

        userAccount.setPassword(password);
        userAccount.setEmailId(email_id);
        userAccount.setLName(lname);
        userAccount.setFName(fname);
        return userAccount;
    }

    public static Address getAddress(){
        Scanner sc = new Scanner(System.in);
        Address address = new Address();
        address.setId( new Random().nextInt(10000));
        String adrs, city,state,country,type;
        int zip;

        System.out.print("Enter address : ");
        adrs = sc.nextLine();

        System.out.print("Enter City : ");
        city = sc.next();

        System.out.print("Enter state : ");
        state = sc.next();

        System.out.print("Enter country : ");
        country = sc.next();

        System.out.print("Enter type : ");
        type = sc.next();

        System.out.print("Enter ZIP : ");
        zip = sc.nextInt();

        address.setAddress(adrs);
        address.setZip(zip);
        address.setCountry(country);
        address.setCity(city);
        address.setState(state);
        address.setType(type);

        return address;
    }
}
